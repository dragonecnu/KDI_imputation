#expressed.protein <- read.table("expressed_notbase.txt",sep='\t',header = T,row.names = 1)
#
# The sample is grouped, such as normal and tumor,
# Before the executive function, please make sure the columns' name and rows' name exists
# expressed.protein: the sample data
# group.indication: the basis for grouping the sample data
GroupSample <- function(expressed.protein, group.indication, writer.permit = FALSE, rearrange.file = NULL){
  expressed.colnames <- colnames(expressed.protein)
  indication.index <- grep(group.indication, expressed.colnames, ignore.case = TRUE)
  indication.colnames <- expressed.colnames[indication.index]
  another.colnames <- expressed.colnames[-indication.index]
  rearrange.names <- c(indication.colnames, another.colnames)
  rearrange.protein <- expressed.protein[,rearrange.names]
  # The sample data eventually are obtained by the rearranged columns' name
  if (writer.permit){
    write.table(expressed.protein,file = rearrange.file,sep='\t')
  }
  return (rearrange.protein)
}
#expressed.protein <- GroupSample(expressed.protein,'ERneg_HER')
# Gain the lines from the sample data, and they are the variables for protein that need to supplement.
# For example, they are that minimum value is greater than 0 or don't contain 'NA',
# the another part is that each line contains 0 or 'NA' and they need to complement the zero.
#
LoadData <- function(covert.select){
  library(rjson)
  select.file <- switch(covert.select, "gene_aliases(hsa).json", "uni2GS.json", "Inweb_ppi(normalization)_sun.json")
  file.name <- fromJSON(file = paste("data",select.file,sep='\\'))
  return(file.name)
}
#
#gene.alias <- LoadData(1)
#
CandiProSet <- function(expressed.protein, divide.base, gene.alias, write.permit = FALSE){
  if (divide.base == 0){
    notbase.namesbool <- apply(expressed.protein,1,function(x){min(abs(x)) > 0})
  }
  if (divide.base == 'NA'){
    notbase.namesbool <- apply(expressed.protein,1,function(x){length(x[is.na(x)]) == 0})
  }
  expressed.notbase <- expressed.protein[notbase.namesbool,]
  notbase.names <- rownames(expressed.notbase)
  normalize.names <<- c()
  for (name in notbase.names){
    if(grepl(';', name)){
      name <- strsplit(name,';')[[1]]
    }
    if (any(name %in% names(gene.alias))){
      name <- paste(paste(gene.alias[name], name, sep='_'), collapse =';')
    }else{
      name <- paste(name, collapse =';')
    }
    normalize.names <- append(normalize.names, name)
  }
  rownames(expressed.notbase) <- normalize.names
  if (write.permit){
    write.table(expressed.notbase,'expressed_notbase.txt',sep='\t')
  }
  return (expressed.notbase)
}
#
#
#
interact.file <- function(protein.name){
  old.name <- protein.name 
  gene.targets <- vector()
  if(grepl(';', protein.name)){
    split.names <- strsplit(protein.name,';')[[1]]
    for (name in split.names){
      if (length(gene.alias[[name]]) >0 ){
        name <- gene.alias[[name]]
      }
      if (length(interact.genes[[name]]) >0 ){
        gene.targets <- append(gene.targets, interact.genes[[name]])
      }
    }
  }else{
    if (length(gene.alias[[protein.name]]) >0 ){
      protein.name <- gene.alias[[protein.name]]
    }
    if (length(interact.genes[[protein.name]]) >0 ){
      gene.targets <- interact.genes[[protein.name]]
    }
  }
  if (length(gene.targets) >0 ){
    process.result <- data.frame(colnames = colnames(expressed.protein))
    gene.hastarget <- c()
    for (target in gene.targets){
      target.row <- grep(paste(paste('((^|;)|_)',target,sep=''),'($|;)',sep=''), notbase.rownames, ignore.case = TRUE)
      gene.hastarget <- c(gene.hastarget, target.row)
    }
    process.result <- rbind(expressed.protein[old.name,],expressed.notbase[gene.hastarget,])
    if (dim(process.result)[1]>1){
      write.table(process.result,paste(paste(folder,old.name,sep='\\'),'txt',sep='.'),sep='\t')
    }
  }
}
#
#
#
create.interact <- function(expressed.protein, gene.alias, divide.base, expressed.notbase, folder){
  #interact.genes <<- LoadData(3)
  #interact.genes <<- fromJSON(file='data\\2_sun(normalization).json')
  #interact.genes <<- fromJSON(file='data\\total_sun(normalization).json')
  interact.genes <<- fromJSON(file='data\\Inweb_ppi(normalization)_sun.json')
  expressed.notbase <<- expressed.notbase
  notbase.rownames <<- row.names(expressed.notbase)
  gene.alias <<- gene.alias
  folder <<- folder
  expressed.hasbase <- expressed.protein
  hasbase.names <- rownames(expressed.hasbase)
  if (!dir.exists(folder)){
    dir.create(folder)
  }
  lapply(hasbase.names,interact.file)
  return ('Interaction has been created !!' )
}
#//////////////////////////
regressed.analysis <- function(analysis.data, analysis.index, percentage){
  data.number <- dim(analysis.data)[2]
  firstline.values <- as.numeric(analysis.data[1,])
  average.value <- sum(firstline.values) / data.number
  analysis.data.T <- t(analysis.data)
  analysis.has0.position <- intersect(has0.position, analysis.index)
  has0.number <- length(analysis.has0.position)
  if (has0.number > 0){
    if((has0.number/data.number ) <= percentage){
      x <- x.all[analysis.has0.position, column.choose, drop = FALSE]
      prediction.x <- data.frame(x)
      #prediction.y <- 0
	  prediction.y <- average.value
      tryCatch({
        prediction.y <- predict(analysis.model, prediction.x, interval="prediction",level=0.95)[,1]
      },warning = function(w){
	    prediction.y <- average.value
		if(analysis.has0.position == 1){
		cat("warning",conditionMessage(e),"\n")
	    }
	  },error = function(e){
	    prediction.y <- average.value
		if(analysis.has0.position == 1){
        cat("error",conditionMessage(e),"\n")
		}
	  })
      prediction.y[which(prediction.y < 0)] <- 0
      return(prediction.y)
    }else{
      #analysis.data[1, ] <- 0
    }
  }
}
#
#
expressed.analysis <- function(file.name, regressed.folder, group.indication, percentage){
  process.data <- read.table(paste(regressed.folder, file.name, sep='\\'))
  column.len <- dim(process.data)[2]
  compute.result <<- c("name","true_value","predict_value")
  firstrow.name <- rownames(process.data[1,])
  source.value <- process.data[1,]
  for (j in (1:column.len)){
  #print(j)
  process.data[1,] <- source.value
  true.value <- process.data[1,j]
  process.data[1,j] <- 0
  has0.position <<- which(process.data[1,] ==0)
  if (length(which(process.data[1,] != 0)) >3){
    process.data.T <<- t(process.data)
    train.y <<- process.data.T[which(process.data.T[,1] !=0),1]
    x.all <<- process.data.T[,-1,drop=FALSE]
    x <- x.all[which(process.data.T[,1]!=0), , drop=FALSE]
    train.x <- data.frame(x)
    var.size <- dim(train.x)[2]
    column.choose <<- c()
    for (i in (1:var.size)){
      cor.value <- cor.test(train.x[,i],train.y)
      if (cor.value$p.value < 0.05){
        column.choose <<- append(column.choose,i)
      }
    }
    process.colnames <- colnames(process.data)
    expressed.base.colindex <- grep(group.indication, process.colnames, ignore.case = TRUE)
    expressed.base.data <- process.data[, expressed.base.colindex]
    expressed.notbase.colindex <- setdiff((1:length(process.colnames)), expressed.base.colindex)
    expressed.notbase.data <- process.data[, expressed.notbase.colindex]
    column.length <- length(column.choose)
    if(column.length > 0){
      train.x <- train.x[ , column.choose, drop = FALSE]
      analysis.model <<- lm(train.y ~ ., data = train.x)
      if(j <= 10){
        predict.value <- regressed.analysis(expressed.base.data, expressed.base.colindex, percentage)
      }else{
        predict.value <- regressed.analysis(expressed.notbase.data, expressed.notbase.colindex, percentage)
      }
    }else{
      if(j <= 10){
	    data.number <- dim(expressed.base.data)[2]
        firstline.values <- as.numeric(expressed.base.data[1,])
        average.value <- sum(firstline.values) / data.number
        predict.value <- average.value
      }else{
        data.number <- dim(expressed.notbase.data)[2]
        firstline.values <- as.numeric(expressed.notbase.data[1,])
        average.value <- sum(firstline.values) / data.number
        predict.value <- average.value
      }
	  if (j ==1) {cat('no related ppi')}
    }
	compute.result <- rbind(compute.result,c(firstrow.name,true.value,predict.value))
  }
}
return (compute.result)
}
#
#
#
regressed.result <- function(regressed.folder, group.indication, percentage){
  files.name <- list.files(regressed.folder)
  combine.results <<- data.frame()
  for (file.name in files.name){
    print (file.name)
    compute.result <- expressed.analysis(file.name, regressed.folder, group.indication, percentage)
    combine.results <- rbind(combine.results,compute.result)
  }
  return (combine.results)
}